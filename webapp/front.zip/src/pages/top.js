import Top from '../components/Leaderboard/top'

export default function TopPage() {
  return <Top />;
}