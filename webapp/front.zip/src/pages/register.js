import Register from '../components/Register/Register';

export default function RegisterPage() {
  return <Register />;
}